package com.fitriana.perusahaankendaraan;

import java.util.ArrayList;

public class PerusahaanKendaraanData {
    private static String[] perusahaankendaraanNames = {
            "Perusahaan BMW",
            "Perusahaan Daihatsu",
            "Perusahaan Datsun",
            "Perusahaan Hino",
            "Perusahaan Honda",
            "Perusahaan Hyundai",
            "Perusahaan Isuzu",
            "Perusahaan Nissan",
            "Perusahaan Suzuki",
            "Perusahaan Toyota",

    };
    private static String[] perusahaankendaraanDetails = {
            "BMW adalah perusahaan besar asal Jerman yang memproduksi mesin dan motor. Didirikan pada tahun 1916 oleh Franz Josef Popp. Perusahaan ini juga pemilik dan produsen mobil'Mini', dan sebagai perusahaan induk dari Rolls-Royce Motor Cars.",
            "PT ASTRA Daihatsu Motor (ADM)  adalah Agen Tunggal Pemegang Merek mobil Daihatsu di Indonesia yang berhak mengimpor, merakit dan membuat kendaraan bermerk Daihatsu/Toyota, dan komponen serta bisnis terkait di Indonesia. ADM merupakan perusahaan joint venture antara Daihatsu Motor Company dengan Astra International yang ada sejak tahun 1978.",
            "Datsun adalah merek mobil yang dimiliki oleh Nissan Motor Company. Datsun digunakan sebagai merek dari kendaraan Nissan yang diekspor tahun 1958 sampai 1986. Pada tahun 2013, Datsun diluncurkan kembali sebagai merek mobil murah Nissan.",
            "Hino Motors, Ltd. atau populer dengan nama Hino adalah perusahaan multinasional yang memproduksi mesin diesel, truk, dan bus. Sejak 1973, perusahaan ini menjadi produsen truk medium dan truk heavy-duty di Jepang. Perusahaan yang didirikan pada tahun 1942 ini berkantor pusat di Hino, Tokyo. Hino merupakan divisi dari Toyota Motor Corporation.",
            "PT Astra Honda Motor adalah sebuah perusahaan yang bergerak dibidang manufaktur, perakitan dan distributor sepeda motor merek Honda. Dan perusahaan ini merupakan satu-satunya di Indonesia yang memiliki hak sebagai Agen Tunggal Pemegang Merek (ATPM) sepeda motor Honda.",
            "Hyundai Motor Company adalah sebuah perusahaan otomotif yang merupakan divisi dari Hyundai Kia Automotive Group dan merupakan produsen mobil terbesar di Korea Selatan. ",
            "Isuzu Motors Ltd. merupakan sebuah perusahaan otomotif Jepang yang memproduksi berbagai macam kendaraan bermesin diesel. Isuzu kebanyakan memproduksi kendaraan komersial dan truk berat. ",
            "Nissan merupakan salah satu perusahaan manufaktur otomotif terbaik di dunia. Sejarah besar Nissan dimulai saat pendiriannya oleh Kwaishinsa pada 1911. Di awal pendiriannya perusahaan ini dikenal dengan nama Kwaishinsa Motor Car Works.",
            "Suzuki Motor Corporation adalah perusahaan Jepang yang memproduksi kendaraan seperti mobil dan sepeda motor. Mereka memiliki tempat produksi yang terletak di lebih dari 22 negara.",
            "PT Toyota-Astra Motor atau biasa disingkat dengan TAM merupakan Agen Tunggal Pemegang Merk (ATPM) Mobil Toyota dan Lexus di Indonesia. TAM merupakan perusahaan joint venture antara PT. Astra International Tbk dengan persentase saham 50% dan Toyota Motor Corporation, Jepang dengan persentase saham 50%."

    };

    private static String[] Sejarah = {
            "BMW mengawali bisnisnya setelah restrukturisasi dari perusahaan pembuat mesin pesawat terbang Rapp Motorenwerke tahun 1917. Akhir dari Perang Dunia I tahun 1918, BMW dipaksa untuk berhenti memproduksi mesin pesawat terbang karena adanya Perjanjian Versailles. Perusahaan ini beralih untuk memproduksi sepeda motor tahun 1923 setelah perjanjian itu mulai dilonggarkan, dan mulai memproduksi mobil tahun 1928/29. \n" +
                    "\n" +
                    "Tahun 1992, BMW mengakuisisi perusahaan studio desain industri di California DesignworksUSA, dan mengakuisisi penuh tahun 1995. Tahun 1994, BMW membeli perusahaan otomotif Inggris Grup Rover (dimana pada saat itu ada merek Rover, Land Rover dan MG dan juga hak atas merek yang sudah tidak lagi diproduksi yaitu Austin dan Morris) dan memilikinya selama 6 tahun. Tahun 2000, Rover mengalami kerugian besar dan BMW pun menjualnya. Merek MG dan Rover dijual ke Phoenix Consortium untuk membentuk MG Rover, sedangkan Land Rover diambil alih Ford. BMW akhirnya mendirikan merek sendiri yang ia namai MINI, yang diluncurkan tahun 2001.",
            "PT Astra Daihatsu Motor (ADM) mengawali sejarahnya pada tahun 1973. Pada tahun 1973, Astra mendapatkan hak untuk mengimpor kendaraan Daihatsu ke Indonesia. Pada tahun 1976, PT Astra International ditunjuk menjadi agen tunggal, importir dan distributor tunggal kendaraan Daihatsu di Indonesia.\n" +
                    "\n" +
                    "PT Astra International, Daihatsu Motor Co., Ltd. dan Nichimen Corporation bersama-sama mendirikan pabrik pengepresan plat baja, PT Daihatsu Indonesia pada tahun 1978. Kemudian pada tahun 1983, pabrik mesin PT Daihatsu Engine Manufacturing Indonesia (DEMI) didirikan. Pada tahun 1987, PT Nasional Astra Motor didirikan sebagai agen tunggal dan pengimpor kendaraan Daihatsu menggantikan posisi PT Astra International. Kemudian pada tahun 1992, PT Astra Daihatsu Motor didirikan melalui penggabungan 3 perusahaan yaitu PT Daihatsu Indonesia, PT Daihatsu Engine Manufacturing Indonesia dan PT National Astra Motor.",
            "Nama ini dibuat pada tahun 1931 oleh DAT Motorcar Co. untuk model baru mobil mereka dengan nama Datson. Pada tahun 1933, setelah Nissan Motor Company mengontrol DAT Motorcar Co., namanya kembali diganti menjadi Datsun. Merek Datsun cukup terkenal dengan mobil sport mereka misalnya mobil roadster Fairlady dan Koupe Fairlady (240Z). Datsun juga cukup terkenal di Indonesia pada zamannya dengan kendaraan pick-up Datsun 620 (Datsun 1500).\n" +
                    "\n" +
                    "Tanggal 20 Maret 2012, Nissan mengumumkan bahwa mereka menghidupkan kembali merek ini untuk pasar Indonesia, Afrika Selatan, India dan Rusia. ",
            "Tahun 1942, Hino Heavy Industry Co. memisahkan diri dari Diesel Motor Industry dan nama Hino pun lahir. Akhir Perang Dunia II, Hino berhenti memproduksi mesin diesel berukuran besar untuk keperluan maritim, lalu juga menghilangkan kata \"Heavy\" pada namanya. \n" +
                    "\n" +
                    "Tahun 1948, Hino menambahkan lagi kata \"Diesel\" pada nama perusahaan menjadi Hino Diesel Industries Co.,Ltd, agar strategi pemasaran ke konsumen bisa diperjelas (dipertajam). Hino bergabung dengan Toyota tahun 1967.",
            "Sejak usia muda, pendiri Honda, Soichiro Honda memiliki minat besar dalam kendaraan bermotor. Dia bekerja sebagai mekanik di Art Shokai, di mana dia menyetel mobil dan dimasukkan kedalam balapan. \n" +
                    "\n" +
                    "Dia kemudian membuat desain piston dan menjualnya ke Toyota. Rancangan pertamanya ditolak, dan Soichiro bekerja keras untuk menyempurnakan desainnya, bahkan dia kembali sekolah dan menggadaikan perhiasan istrinya sebagai jaminan.",
            "Perusahaan ini didirikan pada tahun 1967 oleh Chung Ju-yung dan bermarkas di Yangjae-dong, Seocho-gu, Seoul. Perusahaan otomotif ini berkembang di Korea Selatan dan sanggup menembus pasar internasional yang sebelumnya dikuasai oleh pabrikan otomotif Jepang. Hyundai merupakan perusahaan otomotif dengan pertumbuhan penjualan tercepat di dunia. Hyundai bersama Kia, saat ini adalah produsen mobil terbesar keempat di dunia berdasarkan penjualan tahun 2010. Tahun 2008, Hyundai (tanpa Kia) menempati posisi kedelapan di dunia. Tahun 2010, Hyundai berhasil menjual 3,6 juta unit kendaraan di seluruh dunia.",
            "Perusahaan ini berpusat di Tokyo, didirikan pada tahun 1937. Tahun 2005, Isuzu menjadi produsen truk medium dan truk besar yang terbesar di dunia. \n" +
                    "\n" +
                    "Perusahaan ini mempunyai pabrik di Fujisawa, prefektur Tochigi dan Hokkaido. Perusahaan ini terkenal dengan mesin dieselnya, dengan memproduksi 16 juta mesin dieseln tahun 2003, dan bisa ditemukan di seluruh dunia. ",
            "Masujiro Hashimoto mendirikan The Kwaishinsha Motor Car Works tahun 1911. Tahun 1914, perusahaan ini memproduksi mobil pertamanya, disebut DAT.\n" +
                    "\n" +
                    "Pada tahun 1931, DAT memperkenalkan mobil baru yang lebih kecil, \"Datson\" pertama, artinya \"Anak DAT\" (Son of DAT). Pada tahun 1933, setelah Nissan mengambil alih DAT Motors, ejaan terakhir dari Datson diubah menjadi \"sun\", karena \"son\" artinya \"kehilangan\" dalam bahasa Jepang, sehingga nama akhirnya \"Datsun\" (Dattosan). Pada tahun 1933, nama perusahaan diubah menjadi Jidosha-Seizo Co., Ltd. (Jidōsha Seizō Kabushiki-Gaisha, \"Automobile Manufacturing Co., Ltd.\") dan pindah ke Yokohama.",
            "Suzuki memiliki permulaan yang rendah hati di Jepang sebagai sebuah perusahaan di dangau 1909. Pemilik, Michio Suzuki diinvestasikan dalam dangau untuk membuat mesin-mesin produksi lebih efisien dan menguntungkan. The keuntungan dari dangau produksi tetap mengalami pertumbuhan harga melalui 30 tahun span. Pada saat itu, perusahaan memiliki kekayaan yang cukup untuk berinvestasi di industri lain. Dalam upaya diversifikasi produk mereka, Suzuki diinvestasikan dalam produksi mobil kompak. Mobil suzuki dari warisan dimulai pada 1937. Pertama yang sported model Suzuki 13 daya kuda, empat silinder mesin. Namun, pada serangan hebat dari Perang Dunia II (WWII) Amerika perselisihan produksi dihentikan. Sekali lagi perusahaan investasi mereka kembali ke dangau perusahaan yang akhirnya akan melihat kematian di tahun 1950-an.",
            "Toyota Motor Corporation didirikan pada September 1933 sebagai divisi mobil Pabrik Tenun Otomatis Toyoda. Divisi mobil perusahaan tersebut kemudian dipisahkan pada 27 Agustus 1937 untuk menciptakan Toyota Motor Corporation seperti saat ini. Berangkat dari industri tekstil, Perusahaan yang memproduksi 1 mobil tiap 50 menit ini ternyata menggunakan penamaan Toyota lebih karena penyebutannya lebih enak daripada memakai nama keluarga pendirinya, Toyoda. Inilah beberapa tonggak menarik perjalanan Toyota.Toyota merupakan pabrikan mobil terbesar di dunia dalam unit sales dan net sales. Pabrikan terbesar di Jepang ini menghasilkan 8-8,5 juta unit mobil di seluruh dunia tiap tahunnya."
    };
    private static String[] Berdiri = {
            "Berdiri pada 7 Maret 1916",
            "Berdiri pada 1 Maret 1951",
            "Berdiri pada 1931",
            "Berdiri pada 1 Mei 1942",
            "Berdiri pada 24 September 1948",
            "Berdiri pada 29 Desember 1967",
            "Berdiri pada 1916",
            "Berdiri pada 26 Desember 1933",
            "Berdiri pada Oktober 1909",
            "Berdiri pada September 1933"
    };
    private static int[] perusahaankendaraanImages = {
            R.drawable.bmw1,
            R.drawable.daihatsu1,
            R.drawable.datsun1,
            R.drawable.hino,
            R.drawable.honda,
            R.drawable.hyundai,
            R.drawable.isuzu,
            R.drawable.nissan,
            R.drawable.suzuki,
            R.drawable.toyota
    };

    static ArrayList<PerusahaanKendaraan> getListData(){
        ArrayList<PerusahaanKendaraan> list = new ArrayList<>();
        for(int position = 0; position < perusahaankendaraanNames.length; position++){
            PerusahaanKendaraan perusahaankendaraan = new PerusahaanKendaraan();
            perusahaankendaraan.setName(perusahaankendaraanNames[position]);
            perusahaankendaraan.setBerdiri(Berdiri[position]);
            perusahaankendaraan.setDetail(perusahaankendaraanDetails[position]);
            perusahaankendaraan.setPhoto(perusahaankendaraanImages[position]);
            perusahaankendaraan.setSejarah(Sejarah[position]);
            list.add(perusahaankendaraan);
        }
        return list;
    }
}
