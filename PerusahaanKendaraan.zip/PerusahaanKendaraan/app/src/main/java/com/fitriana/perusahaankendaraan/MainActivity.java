package com.fitriana.perusahaankendaraan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvPerusahaanKendaraan;
    private ArrayList<PerusahaanKendaraan> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        rvPerusahaanKendaraan = findViewById(R.id.rv_perusahaankendaraan);
        rvPerusahaanKendaraan.setHasFixedSize(true);

        list.addAll(PerusahaanKendaraanData.getListData());
        showRecyclerList();
    }

    private void showRecyclerList() {
        rvPerusahaanKendaraan.setLayoutManager(new LinearLayoutManager(this));
        ListPerusahaanKendaraanAdapter listPerusahaanKendaraanAdapter = new ListPerusahaanKendaraanAdapter(list);
        rvPerusahaanKendaraan.setAdapter(listPerusahaanKendaraanAdapter);

        listPerusahaanKendaraanAdapter.setOnItemClickCallback(new ListPerusahaanKendaraanAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(PerusahaanKendaraan data) {
                showSelectedData(data);
            }
        });
    }

    public void showSelectedData(PerusahaanKendaraan l) {
        Intent detail = new Intent(MainActivity.this, DetailPerusahaanKendaraan.class);
        detail.putExtra(DetailPerusahaanKendaraan.EXTRA_NAMAPERUSAHAANKENDARAAN, l.getName());
        detail.putExtra(DetailPerusahaanKendaraan.EXTRA_BERDIRI, l.getBerdiri());
        detail.putExtra(DetailPerusahaanKendaraan.EXTRA_PENGERTIAN, l.getDetail());
        detail.putExtra(DetailPerusahaanKendaraan.EXTRA_SEJARAH, l.getSejarah());
        detail.putExtra(DetailPerusahaanKendaraan.EXTRA_IMG, l.getPhoto());
        startActivity(detail);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent about = new Intent(MainActivity.this, About.class);
        startActivity(about);
        return super.onOptionsItemSelected(item);
    }
}